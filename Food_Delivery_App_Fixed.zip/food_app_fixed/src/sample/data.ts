export const FAQS = [
  { q: 'How do I track my order?', a: 'Go to Orders tab to see live status of your active order.' },
  { q: 'Can I cancel my order?', a: 'You can cancel within 2 minutes of placing. Tap the order and select Cancel.' },
  { q: 'How do I get a refund?', a: 'Refunds are processed within 3-5 business days after approval.' },
  { q: 'Is my payment info secure?', a: 'Yes, we use industry-standard encryption for all payment data.' },
];

export const RESTAURANTS = [
  { id: '1', name: 'Burger Palace', cuisine: 'American', emoji: '🍔', rating: 4.8, price: 12.99, time: '20-30 min' },
  { id: '2', name: 'Pizza Heaven', cuisine: 'Italian', emoji: '🍕', rating: 4.6, price: 14.99, time: '25-35 min' },
  { id: '3', name: 'Sushi World', cuisine: 'Japanese', emoji: '🍣', rating: 4.9, price: 18.99, time: '30-40 min' },
  { id: '4', name: 'Taco Fiesta', cuisine: 'Mexican', emoji: '🌮', rating: 4.5, price: 9.99, time: '15-25 min' },
  { id: '5', name: 'Noodle House', cuisine: 'Chinese', emoji: '🍜', rating: 4.7, price: 11.99, time: '20-30 min' },
  { id: '6', name: 'Curry Corner', cuisine: 'Indian', emoji: '🍛', rating: 4.8, price: 13.99, time: '25-35 min' },
];

export const MOCK_ORDERS = [
  { id: 'o1', restaurant: 'Burger Palace', items: 3, total: 32.97, status: 'Delivered', time: '2 days ago', emoji: '🍔' },
  { id: 'o2', restaurant: 'Sushi World', items: 2, total: 41.98, status: 'Delivered', time: '5 days ago', emoji: '🍣' },
  { id: 'o3', restaurant: 'Pizza Heaven', items: 1, total: 17.98, status: 'Delivered', time: '1 week ago', emoji: '🍕' },
];