import { createContext, useContext, useState, ReactNode } from 'react';

const DARK = {
  bg: '#0A0A0F',
  surface: '#13131A',
  card: '#1C1C26',
  border: '#2A2A3A',
  accent: '#FF5722',
  accentSoft: '#FF572220',
  text: '#FFFFFF',
  textSub: '#9090A8',
  textMuted: '#555568',
  tabBar: '#13131A',
  headerBg: '#0A0A0F',
  inputBg: '#1C1C26',
  isDark: true,
};

const LIGHT = {
  bg: '#F5F5FA',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  border: '#EBEBF0',
  accent: '#FF5722',
  accentSoft: '#FF572215',
  text: '#0A0A0F',
  textSub: '#606078',
  textMuted: '#A0A0B8',
  tabBar: '#FFFFFF',
  headerBg: '#F5F5FA',
  inputBg: '#F0F0F5',
  isDark: false,
};

type Theme = typeof DARK;
type ThemeCtx = { theme: Theme; toggleTheme: () => void };

const ThemeContext = createContext<ThemeCtx>({ theme: DARK, toggleTheme: () => {} });

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [isDark, setIsDark] = useState(true);
  const theme = isDark ? DARK : LIGHT;
  function toggleTheme() { setIsDark(p => !p); }
  return <ThemeContext.Provider value={{ theme, toggleTheme }}>{children}</ThemeContext.Provider>;
}

export function useTheme() { return useContext(ThemeContext); }
