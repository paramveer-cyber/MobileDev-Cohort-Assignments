import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';

export default function SplashScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.iconWrap}>
        <Text style={styles.emoji}>🍔</Text>
      </View>
      <Text style={styles.logo}>FoodApp</Text>
      <ActivityIndicator size="large" color="#FF5722" style={{ marginTop: 40 }} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#0A0A0F' },
  iconWrap: { width: 100, height: 100, borderRadius: 30, backgroundColor: '#FF5722', justifyContent: 'center', alignItems: 'center', marginBottom: 20, shadowColor: '#FF5722', shadowOffset: { width: 0, height: 12 }, shadowOpacity: 0.4, shadowRadius: 20, elevation: 12 },
  emoji: { fontSize: 52 },
  logo: { fontSize: 34, fontWeight: '900', color: '#fff', letterSpacing: -1 },
});
