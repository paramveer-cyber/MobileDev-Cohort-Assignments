import { useState } from 'react';
import { StyleSheet, Text, View, TextInput, Pressable, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

export default function SignUpScreen({ navigation }: { navigation: any }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const { theme } = useTheme();

  function handleSignUp() {
    login(name || email.split('@')[0] || 'Guest User');
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <KeyboardAvoidingView style={styles.kav} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={250}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.text }]}>Create account</Text>
          <Text style={[styles.subtitle, { color: theme.textSub }]}>Join thousands of food lovers</Text>
        </View>

        <View style={[styles.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
          {[
            { label: 'Full Name', val: name, set: setName, placeholder: 'John Doe', secure: false, keyboard: 'default' as const },
            { label: 'Email', val: email, set: setEmail, placeholder: 'you@example.com', secure: false, keyboard: 'email-address' as const },
            { label: 'Password', val: password, set: setPassword, placeholder: '••••••••', secure: true, keyboard: 'default' as const },
          ].map(f => (
            <View key={f.label}>
              <Text style={[styles.fieldLabel, { color: theme.textSub }]}>{f.label}</Text>
              <TextInput
                placeholder={f.placeholder}
                placeholderTextColor={theme.textMuted}
                secureTextEntry={f.secure}
                keyboardType={f.keyboard}
                autoCapitalize="none"
                value={f.val}
                onChangeText={f.set}
                style={[styles.input, { backgroundColor: theme.inputBg, color: theme.text, borderColor: theme.border }]}
              />
            </View>
          ))}

          <Pressable
            style={({ pressed }) => [styles.button, { backgroundColor: theme.accent, opacity: pressed ? 0.85 : 1 }]}
            onPress={handleSignUp}
          >
            <Text style={styles.buttonText}>Create Account</Text>
          </Pressable>
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: theme.textSub }]}>Already have an account?</Text>
          <Pressable onPress={() => navigation.navigate('Signin')}>
            <Text style={[styles.link, { color: theme.accent }]}> Login</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  kav: { flex: 1, justifyContent: 'center', paddingHorizontal: 24 },
  header: { marginBottom: 28 },
  title: { fontSize: 34, fontWeight: '900', letterSpacing: -1, marginBottom: 6 },
  subtitle: { fontSize: 16 },
  card: { borderRadius: 24, padding: 24, borderWidth: 1, marginBottom: 24 },
  fieldLabel: { fontSize: 13, fontWeight: '600', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  input: { borderRadius: 14, paddingHorizontal: 16, paddingVertical: 15, fontSize: 16, marginBottom: 20, borderWidth: 1 },
  button: { paddingVertical: 17, borderRadius: 14, alignItems: 'center', marginTop: 4, shadowColor: '#FF5722', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: '800' },
  footer: { flexDirection: 'row', justifyContent: 'center' },
  footerText: { fontSize: 15 },
  link: { fontWeight: '700', fontSize: 15 },
});
