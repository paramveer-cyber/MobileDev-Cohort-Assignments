import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { FAQS } from '../sample/data';
import { useTheme } from '../context/ThemeContext';

export default function HelpScreen() {
  const { theme } = useTheme();

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.bg }]}>
      {FAQS.map((faq, i) => (
        <View key={i} style={[styles.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={[styles.qIcon, { backgroundColor: theme.accent + '18' }]}>
            <Text style={[styles.qIconText, { color: theme.accent }]}>Q</Text>
          </View>
          <View style={styles.content}>
            <Text style={[styles.q, { color: theme.text }]}>{faq.q}</Text>
            <Text style={[styles.a, { color: theme.textSub }]}>{faq.a}</Text>
          </View>
        </View>
      ))}
      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  card: { flexDirection: 'row', marginHorizontal: 20, marginTop: 12, borderRadius: 18, padding: 16, borderWidth: 1, gap: 14 },
  qIcon: { width: 36, height: 36, borderRadius: 12, justifyContent: 'center', alignItems: 'center', flexShrink: 0 },
  qIconText: { fontSize: 16, fontWeight: '900' },
  content: { flex: 1 },
  q: { fontSize: 15, fontWeight: '700', marginBottom: 6, letterSpacing: -0.2 },
  a: { fontSize: 13, lineHeight: 20 },
});
