import { View, Text, StyleSheet, Pressable, ScrollView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

const MENU_ROWS = [
  { label: 'My Orders', icon: '📦', screen: 'DrawerOrders' },
  { label: 'Settings', icon: '⚙️', screen: 'DrawerSettings' },
  { label: 'Help & Support', icon: '❓', screen: 'DrawerHelp' },
];

export default function ProfileScreen({ navigation }: { navigation: any }) {
  const { userName } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.bg }]} showsVerticalScrollIndicator={false}>
      <View style={[styles.heroCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={[styles.avatar, { backgroundColor: theme.accent }]}>
          <Text style={styles.avatarText}>{(userName || 'G')[0].toUpperCase()}</Text>
        </View>
        <Text style={[styles.name, { color: theme.text }]}>{userName || 'Guest User'}</Text>
        <Text style={[styles.email, { color: theme.textSub }]}>foodlover@email.com</Text>
        <View style={styles.statsRow}>
          {[{ label: 'Orders', val: '12' }, { label: 'Reviews', val: '4' }, { label: 'Points', val: '240' }].map(s => (
            <View key={s.label} style={[styles.stat, { borderRightColor: theme.border }]}>
              <Text style={[styles.statVal, { color: theme.text }]}>{s.val}</Text>
              <Text style={[styles.statLabel, { color: theme.textMuted }]}>{s.label}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={[styles.section, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <Pressable
          style={[styles.themeToggleRow, { borderBottomColor: theme.border }]}
          onPress={toggleTheme}
        >
          <Text style={styles.rowIcon}>{theme.isDark ? '🌙' : '☀️'}</Text>
          <Text style={[styles.rowLabel, { color: theme.text }]}>{theme.isDark ? 'Dark Mode' : 'Light Mode'}</Text>
          <View style={[styles.toggle, { backgroundColor: theme.isDark ? theme.accent : theme.inputBg }]}>
            <View style={[styles.toggleKnob, { marginLeft: theme.isDark ? 18 : 2 }]} />
          </View>
        </Pressable>

        {MENU_ROWS.map((r, i) => (
          <Pressable
            key={r.label}
            style={({ pressed }) => [
              styles.row,
              { borderBottomColor: theme.border, opacity: pressed ? 0.75 : 1 },
              i < MENU_ROWS.length - 1 && styles.rowBorder,
            ]}
            onPress={() => navigation.navigate(r.screen)}
          >
            <Text style={styles.rowIcon}>{r.icon}</Text>
            <Text style={[styles.rowLabel, { color: theme.text }]}>{r.label}</Text>
            <Text style={[styles.rowArrow, { color: theme.textMuted }]}>›</Text>
          </Pressable>
        ))}
      </View>

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  heroCard: { margin: 20, borderRadius: 24, padding: 24, alignItems: 'center', borderWidth: 1 },
  avatar: { width: 88, height: 88, borderRadius: 44, justifyContent: 'center', alignItems: 'center', marginBottom: 14, shadowColor: '#FF5722', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.35, shadowRadius: 16, elevation: 8 },
  avatarText: { color: '#fff', fontSize: 36, fontWeight: '900' },
  name: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5, marginBottom: 4 },
  email: { fontSize: 14, marginBottom: 20 },
  statsRow: { flexDirection: 'row', width: '100%', borderRadius: 14, overflow: 'hidden' },
  stat: { flex: 1, alignItems: 'center', paddingVertical: 4, borderRightWidth: 1 },
  statVal: { fontSize: 20, fontWeight: '800', letterSpacing: -0.3 },
  statLabel: { fontSize: 12, marginTop: 2 },
  section: { marginHorizontal: 20, borderRadius: 20, borderWidth: 1, overflow: 'hidden' },
  themeToggleRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16, borderBottomWidth: 1 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 16 },
  rowBorder: { borderBottomWidth: 1 },
  rowIcon: { fontSize: 20, marginRight: 14, width: 28, textAlign: 'center' },
  rowLabel: { flex: 1, fontSize: 16, fontWeight: '500' },
  rowArrow: { fontSize: 22 },
  toggle: { width: 44, height: 26, borderRadius: 13, justifyContent: 'center', padding: 2 },
  toggleKnob: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#fff' },
});
