import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { MOCK_ORDERS } from '../sample/data';
import { useTheme } from '../context/ThemeContext';

const STATUS_COLORS: Record<string, string> = {
  Delivered: '#22C55E',
  Preparing: '#F59E0B',
  'On the way': '#3B82F6',
};

export default function OrdersScreen() {
  const { theme } = useTheme();

  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.bg }]} showsVerticalScrollIndicator={false}>
      <Text style={[styles.title, { color: theme.text }]}>Your Orders</Text>
      {MOCK_ORDERS.map(order => {
        const statusColor = STATUS_COLORS[order.status] ?? '#888';
        return (
          <View key={order.id} style={[styles.card, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={[styles.cardEmoji, { backgroundColor: theme.accent + '18' }]}>
              <Text style={{ fontSize: 30 }}>{order.emoji}</Text>
            </View>
            <View style={styles.info}>
              <Text style={[styles.restaurant, { color: theme.text }]}>{order.restaurant}</Text>
              <Text style={[styles.meta, { color: theme.textSub }]}>{order.items} items · ${order.total.toFixed(2)}</Text>
              <Text style={[styles.time, { color: theme.textMuted }]}>{order.time}</Text>
            </View>
            <View style={[styles.badge, { backgroundColor: statusColor + '20' }]}>
              <Text style={[styles.badgeText, { color: statusColor }]}>{order.status}</Text>
            </View>
          </View>
        );
      })}
      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  title: { fontSize: 28, fontWeight: '900', paddingHorizontal: 20, paddingTop: 20, paddingBottom: 16, letterSpacing: -0.8 },
  card: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 20, marginBottom: 12, borderRadius: 18, padding: 14, borderWidth: 1 },
  cardEmoji: { width: 56, height: 56, borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  info: { flex: 1, gap: 3 },
  restaurant: { fontSize: 16, fontWeight: '700', letterSpacing: -0.2 },
  meta: { fontSize: 13 },
  time: { fontSize: 12 },
  badge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  badgeText: { fontSize: 12, fontWeight: '700' },
});
