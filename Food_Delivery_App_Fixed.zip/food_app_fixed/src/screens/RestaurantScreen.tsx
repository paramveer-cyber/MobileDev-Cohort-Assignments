import { View, Text, StyleSheet, ScrollView, Pressable, StatusBar } from 'react-native';
import { useCart } from '../context/CartContext';
import { useTheme } from '../context/ThemeContext';

const MENU = [
  { id: 'm1', name: 'Signature Burger', desc: 'Double patty, cheddar, special sauce', price: 12.99, emoji: '🍔' },
  { id: 'm2', name: 'Crispy Fries', desc: 'Golden fried, seasoned with sea salt', price: 4.99, emoji: '🍟' },
  { id: 'm3', name: 'Milkshake', desc: 'Vanilla, chocolate or strawberry', price: 6.99, emoji: '🥤' },
  { id: 'm4', name: 'Loaded Nachos', desc: 'Jalapeños, cheese, sour cream', price: 8.99, emoji: '🧀' },
  { id: 'm5', name: 'Chicken Wings', desc: '8 pieces, BBQ or buffalo sauce', price: 11.99, emoji: '🍗' },
  { id: 'm6', name: 'Garden Salad', desc: 'Fresh greens, house vinaigrette', price: 7.99, emoji: '🥗' },
];

export default function RestaurantScreen({ navigation, route }: { navigation: any; route: any }) {
  const { restaurant } = route.params;
  const { addItem, items } = useCart();
  const { theme } = useTheme();
  const cartCount = items.reduce((s, i) => s + i.qty, 0);
  const cartTotal = items.reduce((s, i) => s + i.price * i.qty, 0);

  const itemQty = (id: string) => items.find(i => i.id === id)?.qty ?? 0;

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={[styles.hero, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
          <View style={[styles.heroIcon, { backgroundColor: theme.accent + '18' }]}>
            <Text style={styles.heroEmoji}>{restaurant.emoji}</Text>
          </View>
          <Text style={[styles.name, { color: theme.text }]}>{restaurant.name}</Text>
          <Text style={[styles.cuisine, { color: theme.textSub }]}>{restaurant.cuisine}</Text>
          <View style={styles.metaRow}>
            <View style={[styles.metaBadge, { backgroundColor: theme.accent + '18' }]}>
              <Text style={[styles.metaBadgeText, { color: theme.accent }]}>⭐ {restaurant.rating}</Text>
            </View>
            <View style={[styles.metaBadge, { backgroundColor: theme.inputBg }]}>
              <Text style={[styles.metaBadgeText, { color: theme.textSub }]}>🕐 {restaurant.time}</Text>
            </View>
            <View style={[styles.metaBadge, { backgroundColor: theme.inputBg }]}>
              <Text style={[styles.metaBadgeText, { color: theme.textSub }]}>From ${restaurant.price}</Text>
            </View>
          </View>
        </View>

        <Text style={[styles.menuTitle, { color: theme.text }]}>Menu</Text>

        {MENU.map(item => {
          const qty = itemQty(item.id);
          return (
            <View key={item.id} style={[styles.menuItem, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <View style={[styles.menuEmoji, { backgroundColor: theme.accent + '12' }]}>
                <Text style={{ fontSize: 28 }}>{item.emoji}</Text>
              </View>
              <View style={styles.menuInfo}>
                <Text style={[styles.menuName, { color: theme.text }]}>{item.name}</Text>
                <Text style={[styles.menuDesc, { color: theme.textSub }]}>{item.desc}</Text>
                <Text style={[styles.menuPrice, { color: theme.accent }]}>${item.price.toFixed(2)}</Text>
              </View>
              <Pressable
                style={({ pressed }) => [styles.addBtn, { backgroundColor: theme.accent, opacity: pressed ? 0.75 : 1 }]}
                onPress={() => addItem({ id: item.id, name: item.name, price: item.price })}
              >
                <Text style={styles.addBtnText}>{qty > 0 ? qty : '+'}</Text>
              </Pressable>
            </View>
          );
        })}
        <View style={{ height: 120 }} />
      </ScrollView>

      {cartCount > 0 && (
        <View style={[styles.cartBar, { backgroundColor: theme.bg, borderTopColor: theme.border }]}>
          <Pressable
            style={({ pressed }) => [styles.cartBtn, { backgroundColor: theme.accent, opacity: pressed ? 0.88 : 1 }]}
            onPress={() => navigation.navigate('Cart')}
          >
            <View style={styles.cartCountWrap}>
              <Text style={styles.cartCount}>{cartCount}</Text>
            </View>
            <Text style={styles.cartBtnText}>View Cart</Text>
            <Text style={styles.cartBtnTotal}>${cartTotal.toFixed(2)}</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  hero: { alignItems: 'center', padding: 28, paddingTop: 24, borderBottomWidth: 1 },
  heroIcon: { width: 100, height: 100, borderRadius: 28, justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  heroEmoji: { fontSize: 56 },
  name: { fontSize: 26, fontWeight: '800', letterSpacing: -0.6, marginBottom: 4 },
  cuisine: { fontSize: 14, marginBottom: 16 },
  metaRow: { flexDirection: 'row', gap: 8 },
  metaBadge: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  metaBadgeText: { fontSize: 13, fontWeight: '600' },
  menuTitle: { fontSize: 20, fontWeight: '800', paddingHorizontal: 20, marginTop: 24, marginBottom: 12, letterSpacing: -0.4 },
  menuItem: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 20, marginBottom: 10, borderRadius: 18, padding: 14, borderWidth: 1 },
  menuEmoji: { width: 56, height: 56, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  menuInfo: { flex: 1 },
  menuName: { fontSize: 16, fontWeight: '700', marginBottom: 2, letterSpacing: -0.2 },
  menuDesc: { fontSize: 12, marginBottom: 6, lineHeight: 16 },
  menuPrice: { fontSize: 15, fontWeight: '800' },
  addBtn: { width: 38, height: 38, borderRadius: 19, justifyContent: 'center', alignItems: 'center', marginLeft: 10 },
  addBtnText: { color: '#fff', fontSize: 20, fontWeight: '800', lineHeight: 24 },
  cartBar: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, borderTopWidth: 1 },
  cartBtn: { borderRadius: 18, paddingVertical: 16, paddingHorizontal: 20, flexDirection: 'row', alignItems: 'center', shadowColor: '#FF5722', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 },
  cartCountWrap: { backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: 12, width: 28, height: 28, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  cartCount: { color: '#fff', fontSize: 13, fontWeight: '800' },
  cartBtnText: { color: '#fff', fontSize: 16, fontWeight: '700', flex: 1 },
  cartBtnTotal: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
