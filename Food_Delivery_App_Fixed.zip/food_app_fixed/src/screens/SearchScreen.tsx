import { View, Text, StyleSheet, TextInput, FlatList, Pressable } from 'react-native';
import { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { RESTAURANTS } from '../sample/data';

export default function SearchScreen({ navigation }: { navigation: any }) {
  const [query, setQuery] = useState('');
  const { theme } = useTheme();

  const results = query.length > 0
    ? RESTAURANTS.filter(r =>
        r.name.toLowerCase().includes(query.toLowerCase()) ||
        r.cuisine.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={[styles.searchWrap, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <Text style={styles.icon}>🔍</Text>
        <TextInput
          style={[styles.input, { color: theme.text }]}
          placeholder="Search restaurants or cuisine..."
          placeholderTextColor={theme.textMuted}
          value={query}
          onChangeText={setQuery}
          autoFocus
        />
        {query.length > 0 && (
          <Pressable onPress={() => setQuery('')}>
            <Text style={[styles.clearIcon, { color: theme.textMuted }]}>✕</Text>
          </Pressable>
        )}
      </View>

      {query.length === 0 ? (
        <View style={styles.hint}>
          <Text style={styles.hintEmoji}>🍽️</Text>
          <Text style={[styles.hintTitle, { color: theme.text }]}>Search for food</Text>
          <Text style={[styles.hintSub, { color: theme.textSub }]}>Find restaurants by name or cuisine</Text>
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={r => r.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => (
            <Pressable
              style={({ pressed }) => [styles.card, { backgroundColor: theme.card, borderColor: theme.border, opacity: pressed ? 0.88 : 1 }]}
              onPress={() => navigation.navigate('HomeTab', { screen: 'RestaurantDetail', params: { restaurant: item } })}
            >
              <View style={[styles.cardEmoji, { backgroundColor: theme.accent + '18' }]}>
                <Text style={{ fontSize: 32 }}>{item.emoji}</Text>
              </View>
              <View style={styles.info}>
                <Text style={[styles.name, { color: theme.text }]}>{item.name}</Text>
                <Text style={[styles.meta, { color: theme.textSub }]}>{item.cuisine} · ⭐ {item.rating}</Text>
                <Text style={[styles.time, { color: theme.textMuted }]}>🕐 {item.time} · From ${item.price}</Text>
              </View>
            </Pressable>
          )}
          ListEmptyComponent={
            <View style={styles.noResults}>
              <Text style={styles.noResultsEmoji}>🤔</Text>
              <Text style={[styles.noResultsText, { color: theme.textSub }]}>No results for "{query}"</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  searchWrap: { flexDirection: 'row', alignItems: 'center', margin: 16, borderRadius: 18, paddingHorizontal: 16, borderWidth: 1 },
  icon: { fontSize: 16, marginRight: 10 },
  input: { flex: 1, fontSize: 16, paddingVertical: 14 },
  clearIcon: { fontSize: 16, paddingLeft: 8 },
  hint: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 8 },
  hintEmoji: { fontSize: 52, marginBottom: 4 },
  hintTitle: { fontSize: 20, fontWeight: '700', letterSpacing: -0.3 },
  hintSub: { fontSize: 15 },
  card: { flexDirection: 'row', borderRadius: 18, marginBottom: 10, padding: 14, alignItems: 'center', borderWidth: 1 },
  cardEmoji: { width: 60, height: 60, borderRadius: 16, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  info: { flex: 1, gap: 3 },
  name: { fontSize: 16, fontWeight: '700', letterSpacing: -0.2 },
  meta: { fontSize: 13 },
  time: { fontSize: 12 },
  noResults: { alignItems: 'center', marginTop: 40, gap: 10 },
  noResultsEmoji: { fontSize: 48 },
  noResultsText: { fontSize: 16 },
});
