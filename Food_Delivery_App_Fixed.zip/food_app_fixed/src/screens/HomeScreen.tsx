import { View, Text, StyleSheet, FlatList, Pressable, ScrollView, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { RESTAURANTS } from '../sample/data';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';

const CATEGORIES = ['All', '🍔 Burgers', '🍕 Pizza', '🍣 Sushi', '🌮 Mexican', '🍜 Noodles'];

export default function HomeScreen({ navigation }: { navigation: any }) {
  const { theme, toggleTheme } = useTheme();
  const { userName } = useAuth();

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <StatusBar barStyle={theme.isDark ? 'light-content' : 'dark-content'} />
      <SafeAreaView edges={['top']}>
        <View style={styles.topBar}>
          <View>
            <Text style={[styles.greeting, { color: theme.textSub }]}>Good morning 👋</Text>
            <Text style={[styles.userName, { color: theme.text }]}>{userName || 'Foodie'}</Text>
          </View>
          <Pressable
            style={[styles.themeBtn, { backgroundColor: theme.card, borderColor: theme.border }]}
            onPress={toggleTheme}
          >
            <Text style={styles.themeIcon}>{theme.isDark ? '☀️' : '🌙'}</Text>
          </Pressable>
        </View>

        <View style={[styles.searchBar, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <Text style={styles.searchIcon}>🔍</Text>
          <Text style={[styles.searchPlaceholder, { color: theme.textMuted }]}>Search restaurants, cuisines...</Text>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoriesRow}>
          {CATEGORIES.map((c, i) => (
            <Pressable
              key={c}
              style={[
                styles.categoryPill,
                { backgroundColor: i === 0 ? theme.accent : theme.card, borderColor: i === 0 ? theme.accent : theme.border },
              ]}
            >
              <Text style={[styles.categoryText, { color: i === 0 ? '#fff' : theme.textSub }]}>{c}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </SafeAreaView>

      <FlatList
        data={RESTAURANTS}
        keyExtractor={r => r.id}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <Text style={[styles.sectionTitle, { color: theme.text }]}>Featured Restaurants</Text>
        }
        contentContainerStyle={{ paddingBottom: 24 }}
        renderItem={({ item }) => (
          <Pressable
            style={({ pressed }) => [styles.card, { backgroundColor: theme.card, borderColor: theme.border, opacity: pressed ? 0.92 : 1, transform: [{ scale: pressed ? 0.985 : 1 }] }]}
            onPress={() => navigation.navigate('RestaurantDetail', { restaurant: item })}
          >
            <View style={[styles.cardEmoji, { backgroundColor: theme.accent + '18' }]}>
              <Text style={styles.emoji}>{item.emoji}</Text>
            </View>
            <View style={styles.cardBody}>
              <View style={styles.cardTop}>
                <Text style={[styles.cardName, { color: theme.text }]}>{item.name}</Text>
                <View style={[styles.ratingBadge, { backgroundColor: theme.accent + '18' }]}>
                  <Text style={[styles.ratingText, { color: theme.accent }]}>⭐ {item.rating}</Text>
                </View>
              </View>
              <Text style={[styles.cardCuisine, { color: theme.textSub }]}>{item.cuisine}</Text>
              <View style={styles.cardMeta}>
                <Text style={[styles.metaChip, { color: theme.textMuted }]}>🕐 {item.time}</Text>
                <Text style={[styles.metaChip, { color: theme.textMuted }]}>From ${item.price}</Text>
              </View>
            </View>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 8, paddingBottom: 16 },
  greeting: { fontSize: 14, marginBottom: 2 },
  userName: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  themeBtn: { width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', borderWidth: 1 },
  themeIcon: { fontSize: 20 },
  searchBar: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 20, borderRadius: 16, paddingHorizontal: 16, paddingVertical: 13, borderWidth: 1, marginBottom: 16 },
  searchIcon: { fontSize: 16, marginRight: 10 },
  searchPlaceholder: { fontSize: 15 },
  categoriesRow: { paddingHorizontal: 20, gap: 8, paddingBottom: 4 },
  categoryPill: { paddingHorizontal: 16, paddingVertical: 9, borderRadius: 20, borderWidth: 1 },
  categoryText: { fontSize: 13, fontWeight: '600' },
  sectionTitle: { fontSize: 20, fontWeight: '800', paddingHorizontal: 20, paddingTop: 20, paddingBottom: 12, letterSpacing: -0.4 },
  card: { flexDirection: 'row', marginHorizontal: 20, marginBottom: 12, borderRadius: 20, padding: 14, borderWidth: 1, alignItems: 'center' },
  cardEmoji: { width: 72, height: 72, borderRadius: 18, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  emoji: { fontSize: 38 },
  cardBody: { flex: 1 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 },
  cardName: { fontSize: 17, fontWeight: '700', letterSpacing: -0.3, flex: 1 },
  ratingBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  ratingText: { fontSize: 12, fontWeight: '700' },
  cardCuisine: { fontSize: 13, marginBottom: 8 },
  cardMeta: { flexDirection: 'row', gap: 12 },
  metaChip: { fontSize: 12, fontWeight: '500' },
});
