import { View, Text, StyleSheet, Pressable, Dimensions } from 'react-native';
import { useTheme } from '../context/ThemeContext';

const { width } = Dimensions.get('window');

export default function OnboardingScreen({ navigation }: { navigation: any }) {
  const { theme } = useTheme();

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.topDecor}>
        <View style={[styles.circle1, { backgroundColor: theme.accent + '18' }]} />
        <View style={[styles.circle2, { backgroundColor: theme.accent + '10' }]} />
      </View>

      <View style={styles.hero}>
        <View style={[styles.iconWrap, { backgroundColor: theme.accent }]}>
          <Text style={styles.iconEmoji}>🍔</Text>
        </View>
        <Text style={[styles.brand, { color: theme.text }]}>FoodApp</Text>
        <Text style={[styles.tagline, { color: theme.textSub }]}>
          Discover the best food{'\n'}delivered fast to your door.
        </Text>

        <View style={styles.pillRow}>
          {['🍕 Pizza', '🍣 Sushi', '🌮 Tacos', '🍜 Noodles'].map(t => (
            <View key={t} style={[styles.pill, { backgroundColor: theme.card, borderColor: theme.border }]}>
              <Text style={[styles.pillText, { color: theme.textSub }]}>{t}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.bottom}>
        <Pressable
          style={({ pressed }) => [styles.btn, { backgroundColor: theme.accent, opacity: pressed ? 0.85 : 1 }]}
          onPress={() => navigation.replace('Signin')}
        >
          <Text style={styles.btnText}>Get Started →</Text>
        </Pressable>
        <Text style={[styles.legal, { color: theme.textMuted }]}>
          By continuing you agree to our Terms & Privacy Policy
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topDecor: { position: 'absolute', top: 0, right: 0, width: width, height: width },
  circle1: { position: 'absolute', top: -80, right: -80, width: 300, height: 300, borderRadius: 150 },
  circle2: { position: 'absolute', top: 60, right: -40, width: 200, height: 200, borderRadius: 100 },
  hero: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 32 },
  iconWrap: { width: 100, height: 100, borderRadius: 32, justifyContent: 'center', alignItems: 'center', marginBottom: 28, shadowColor: '#FF5722', shadowOffset: { width: 0, height: 12 }, shadowOpacity: 0.4, shadowRadius: 20, elevation: 12 },
  iconEmoji: { fontSize: 52 },
  brand: { fontSize: 46, fontWeight: '900', letterSpacing: -1.5, marginBottom: 14 },
  tagline: { fontSize: 17, textAlign: 'center', lineHeight: 26, marginBottom: 36 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  pillText: { fontSize: 13, fontWeight: '500' },
  bottom: { padding: 32, paddingBottom: 48 },
  btn: { paddingVertical: 18, borderRadius: 18, alignItems: 'center', shadowColor: '#FF5722', shadowOffset: { width: 0, height: 8 }, shadowOpacity: 0.35, shadowRadius: 16, elevation: 8 },
  btnText: { color: '#fff', fontSize: 17, fontWeight: '800', letterSpacing: 0.3 },
  legal: { textAlign: 'center', fontSize: 12, marginTop: 16, lineHeight: 18 },
});
