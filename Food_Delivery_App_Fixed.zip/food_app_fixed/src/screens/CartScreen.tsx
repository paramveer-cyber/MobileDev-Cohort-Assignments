import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { useCart } from '../context/CartContext';
import { useTheme } from '../context/ThemeContext';

export default function CartScreen({ navigation }: { navigation: any }) {
  const { items, addItem, removeItem, clearCart, total } = useCart();
  const { theme } = useTheme();

  if (items.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: theme.bg }]}>
        <Text style={styles.emptyEmoji}>🛒</Text>
        <Text style={[styles.emptyTitle, { color: theme.text }]}>Your cart is empty</Text>
        <Text style={[styles.emptySubtitle, { color: theme.textSub }]}>Add some delicious items!</Text>
        <Pressable
          style={({ pressed }) => [styles.backBtn, { backgroundColor: theme.accent, opacity: pressed ? 0.85 : 1 }]}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backBtnText}>Browse Restaurants</Text>
        </Pressable>
      </View>
    );
  }

  const delivery = 2.99;
  const grandTotal = total + delivery;

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Order Summary</Text>
        {items.map(item => (
          <View key={item.id} style={[styles.item, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <View style={styles.itemInfo}>
              <Text style={[styles.itemName, { color: theme.text }]}>{item.name}</Text>
              <Text style={[styles.itemUnitPrice, { color: theme.textSub }]}>${item.price.toFixed(2)} each</Text>
            </View>
            <View style={styles.itemRight}>
              <Text style={[styles.itemTotal, { color: theme.accent }]}>${(item.price * item.qty).toFixed(2)}</Text>
              <View style={styles.qtyRow}>
                <Pressable style={[styles.qtyBtn, { backgroundColor: theme.inputBg, borderColor: theme.border }]} onPress={() => removeItem(item.id)}>
                  <Text style={[styles.qtyBtnText, { color: theme.text }]}>−</Text>
                </Pressable>
                <Text style={[styles.qty, { color: theme.text }]}>{item.qty}</Text>
                <Pressable style={[styles.qtyBtn, { backgroundColor: theme.accent }]} onPress={() => addItem({ id: item.id, name: item.name, price: item.price })}>
                  <Text style={[styles.qtyBtnText, { color: '#fff' }]}>+</Text>
                </Pressable>
              </View>
            </View>
          </View>
        ))}

        <View style={[styles.summary, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: theme.textSub }]}>Subtotal</Text>
            <Text style={[styles.summaryVal, { color: theme.text }]}>${total.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: theme.textSub }]}>Delivery</Text>
            <Text style={[styles.summaryVal, { color: theme.text }]}>${delivery.toFixed(2)}</Text>
          </View>
          <View style={[styles.summaryDivider, { backgroundColor: theme.border }]} />
          <View style={styles.summaryRow}>
            <Text style={[styles.grandLabel, { color: theme.text }]}>Total</Text>
            <Text style={[styles.grandVal, { color: theme.accent }]}>${grandTotal.toFixed(2)}</Text>
          </View>
        </View>
        <View style={{ height: 130 }} />
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: theme.bg, borderTopColor: theme.border }]}>
        <Pressable
          style={({ pressed }) => [styles.clearBtn, { backgroundColor: theme.card, borderColor: theme.border, opacity: pressed ? 0.7 : 1 }]}
          onPress={clearCart}
        >
          <Text style={[styles.clearBtnText, { color: theme.textSub }]}>Clear</Text>
        </Pressable>
        <Pressable
          style={({ pressed }) => [styles.placeBtn, { backgroundColor: theme.accent, opacity: pressed ? 0.88 : 1, shadowColor: theme.accent }]}
          onPress={() => {
            clearCart();
            navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
          }}
        >
          <Text style={styles.placeBtnText}>Place Order · ${grandTotal.toFixed(2)}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 32 },
  emptyEmoji: { fontSize: 72, marginBottom: 20 },
  emptyTitle: { fontSize: 24, fontWeight: '800', marginBottom: 8, letterSpacing: -0.5 },
  emptySubtitle: { fontSize: 15, marginBottom: 32 },
  backBtn: { paddingHorizontal: 28, paddingVertical: 15, borderRadius: 16 },
  backBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
  sectionTitle: { fontSize: 22, fontWeight: '800', paddingHorizontal: 20, marginTop: 20, marginBottom: 14, letterSpacing: -0.5 },
  item: { flexDirection: 'row', marginHorizontal: 20, marginBottom: 10, borderRadius: 18, padding: 16, borderWidth: 1 },
  itemInfo: { flex: 1 },
  itemName: { fontSize: 16, fontWeight: '700', marginBottom: 4, letterSpacing: -0.2 },
  itemUnitPrice: { fontSize: 13 },
  itemRight: { alignItems: 'flex-end', gap: 10 },
  itemTotal: { fontSize: 16, fontWeight: '800' },
  qtyRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  qtyBtn: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center', borderWidth: 1 },
  qtyBtnText: { fontSize: 18, fontWeight: '700', lineHeight: 22 },
  qty: { fontSize: 17, fontWeight: '700', minWidth: 22, textAlign: 'center' },
  summary: { marginHorizontal: 20, borderRadius: 20, padding: 20, borderWidth: 1, gap: 10 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  summaryLabel: { fontSize: 15 },
  summaryVal: { fontSize: 15, fontWeight: '600' },
  summaryDivider: { height: 1, marginVertical: 4 },
  grandLabel: { fontSize: 18, fontWeight: '800' },
  grandVal: { fontSize: 18, fontWeight: '900' },
  footer: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16, borderTopWidth: 1, flexDirection: 'row', gap: 12 },
  clearBtn: { borderRadius: 16, paddingVertical: 17, paddingHorizontal: 20, borderWidth: 1 },
  clearBtnText: { fontWeight: '700', fontSize: 15 },
  placeBtn: { flex: 1, paddingVertical: 17, borderRadius: 16, alignItems: 'center', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 },
  placeBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
