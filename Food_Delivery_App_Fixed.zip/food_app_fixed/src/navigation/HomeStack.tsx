import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import RestaurantScreen from '../screens/RestaurantScreen';
import CartScreen from '../screens/CartScreen';
import { useTheme } from '../context/ThemeContext';

const Stack = createStackNavigator();

export function HomeStack() {
  const { theme } = useTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: theme.headerBg },
        headerTintColor: theme.text,
        headerBackTitle: 'Back',
        cardStyleInterpolator: ({ current, layouts }) => ({
          cardStyle: {
            transform: [{
              translateX: current.progress.interpolate({
                inputRange: [0, 1],
                outputRange: [layouts.screen.width, 0],
              }),
            }],
          },
        }),
      }}
    >
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="RestaurantDetail"
        component={RestaurantScreen}
        options={({ route }: { route: any }) => ({
          title: route.params?.restaurant?.name || 'Restaurant',
          headerStyle: { backgroundColor: theme.headerBg },
          headerTintColor: theme.text,
        })}
      />
      <Stack.Screen
        name="Cart"
        component={CartScreen}
        options={{
          title: 'Your Cart',
          presentation: 'modal',
          headerStyle: { backgroundColor: theme.headerBg },
          headerTintColor: theme.text,
        }}
      />
    </Stack.Navigator>
  );
}
