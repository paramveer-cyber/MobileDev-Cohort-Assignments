import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@react-native-vector-icons/ionicons';
import { useCart } from '../context/CartContext';
import { useTheme } from '../context/ThemeContext';
import { View, Text, StyleSheet } from 'react-native';
import { HomeStack } from './HomeStack';
import SearchScreen from '../screens/SearchScreen';
import OrdersScreen from '../screens/OrdersScreen';
import ProfileScreen from '../screens/ProfileScreen';
import { useNavigationState } from '@react-navigation/native';

function CartBadge() {
  const { items } = useCart();
  const { theme } = useTheme();
  const count = items.reduce((s, i) => s + i.qty, 0);
  if (count === 0) return null;
  return (
    <View style={[badge.dot, { backgroundColor: theme.accent }]}>
      <Text style={badge.text}>{count > 9 ? '9+' : count}</Text>
    </View>
  );
}

const badge = StyleSheet.create({
  dot: { position: 'absolute', top: -4, right: -8, borderRadius: 10, minWidth: 18, height: 18, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 4 },
  text: { color: '#fff', fontSize: 11, fontWeight: '800' },
});

const Tab = createBottomTabNavigator();

function isTabBarHidden(navState: any) {
  if (!navState) return false;
  const homeTab = navState.routes?.find((r: any) => r.name === 'HomeTab');
  if (!homeTab?.state) return false;
  const active = homeTab.state.routes[homeTab.state.index ?? 0];
  return active?.name === 'RestaurantDetail' || active?.name === 'Cart';
}

export function BottomTab() {
  const navState = useNavigationState(s => s);
  const { theme } = useTheme();
  const hidden = isTabBarHidden(navState);

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: hidden
          ? { display: 'none' }
          : {
              backgroundColor: theme.tabBar,
              borderTopColor: theme.border,
              height: 62,
              paddingBottom: 8,
              paddingTop: 6,
            },
        tabBarActiveTintColor: theme.accent,
        tabBarInactiveTintColor: theme.textMuted,
      }}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeStack}
        options={{
          title: 'Home',
          tabBarIcon: ({ color, size }) => <Ionicons name="home" color={color} size={size} />,
        }}
      />
      <Tab.Screen
        name="Search"
        component={SearchScreen}
        options={{
          tabBarIcon: ({ color, size }) => <Ionicons name="search" color={color} size={size} />,
        }}
      />
      <Tab.Screen
        name="Orders"
        component={OrdersScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <View>
              <Ionicons name="list" color={color} size={size} />
              <CartBadge />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarIcon: ({ color, size }) => <Ionicons name="person" color={color} size={size} />,
        }}
      />
    </Tab.Navigator>
  );
}
