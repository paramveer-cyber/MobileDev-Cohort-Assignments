import { createDrawerNavigator, DrawerContentScrollView } from '@react-navigation/drawer';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { BottomTab } from './BottomTab';
import OrdersScreen from '../screens/OrdersScreen';
import SettingsScreen from '../screens/SettingsScreen';
import HelpScreen from '../screens/HelpScreen';

function CustomDrawerContent(props: any) {
  const { userName, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <DrawerContentScrollView {...props} style={{ backgroundColor: theme.bg }}>
      <View style={[styles.drawerHeader, { borderBottomColor: theme.border }]}>
        <View style={[styles.drawerAvatar, { backgroundColor: theme.accent }]}>
          <Text style={styles.drawerAvatarText}>{(userName || 'G')[0].toUpperCase()}</Text>
        </View>
        <Text style={[styles.drawerName, { color: theme.text }]}>{userName || 'Guest User'}</Text>
        <Text style={[styles.drawerEmail, { color: theme.textSub }]}>foodlover@email.com</Text>
      </View>

      <View style={styles.drawerItems}>
        {[
          { label: 'My Orders', icon: '📦', screen: 'DrawerOrders' },
          { label: 'Settings', icon: '⚙️', screen: 'DrawerSettings' },
          { label: 'Help', icon: '❓', screen: 'DrawerHelp' },
        ].map(item => (
          <Pressable
            key={item.label}
            style={({ pressed }) => [styles.drawerItem, { backgroundColor: pressed ? theme.card : 'transparent' }]}
            onPress={() => props.navigation.navigate(item.screen)}
          >
            <Text style={styles.drawerItemIcon}>{item.icon}</Text>
            <Text style={[styles.drawerItemLabel, { color: theme.text }]}>{item.label}</Text>
            <Text style={[styles.drawerArrow, { color: theme.textMuted }]}>›</Text>
          </Pressable>
        ))}

        <Pressable
          style={({ pressed }) => [styles.drawerItem, { backgroundColor: pressed ? theme.card : 'transparent' }]}
          onPress={toggleTheme}
        >
          <Text style={styles.drawerItemIcon}>{theme.isDark ? '☀️' : '🌙'}</Text>
          <Text style={[styles.drawerItemLabel, { color: theme.text }]}>{theme.isDark ? 'Light Mode' : 'Dark Mode'}</Text>
        </Pressable>
      </View>

      <View style={[styles.drawerDivider, { backgroundColor: theme.border }]} />

      <Pressable
        style={({ pressed }) => [styles.drawerItem, { backgroundColor: pressed ? theme.card : 'transparent', marginHorizontal: 8 }]}
        onPress={() => { props.navigation.closeDrawer(); logout(); }}
      >
        <Text style={styles.drawerItemIcon}>🚪</Text>
        <Text style={[styles.drawerItemLabel, { color: theme.accent }]}>Logout</Text>
      </Pressable>
    </DrawerContentScrollView>
  );
}

const Drawer = createDrawerNavigator();

export function DrawerNavigator() {
  const { theme } = useTheme();

  return (
    <Drawer.Navigator
      drawerContent={props => <CustomDrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        drawerStyle: { backgroundColor: theme.bg, width: 280 },
        drawerType: 'slide',
        overlayColor: 'rgba(0,0,0,0.5)',
        swipeEdgeWidth: 40,
      }}
    >
      <Drawer.Screen name="MainTabs" component={BottomTab} />
      <Drawer.Screen
        name="DrawerOrders"
        component={OrdersScreen}
        options={{ headerShown: true, headerStyle: { backgroundColor: theme.headerBg }, headerTintColor: theme.text, title: 'My Orders' }}
      />
      <Drawer.Screen
        name="DrawerSettings"
        component={SettingsScreen}
        options={{ headerShown: true, headerStyle: { backgroundColor: theme.headerBg }, headerTintColor: theme.text, title: 'Settings' }}
      />
      <Drawer.Screen
        name="DrawerHelp"
        component={HelpScreen}
        options={{ headerShown: true, headerStyle: { backgroundColor: theme.headerBg }, headerTintColor: theme.text, title: 'Help & Support' }}
      />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  drawerHeader: { padding: 24, paddingBottom: 20, borderBottomWidth: 1, marginBottom: 8 },
  drawerAvatar: { width: 72, height: 72, borderRadius: 36, justifyContent: 'center', alignItems: 'center', marginBottom: 12, shadowColor: '#FF5722', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 },
  drawerAvatarText: { color: '#fff', fontSize: 28, fontWeight: '900' },
  drawerName: { fontSize: 18, fontWeight: '800', marginBottom: 3, letterSpacing: -0.3 },
  drawerEmail: { fontSize: 13 },
  drawerItems: { paddingHorizontal: 8 },
  drawerItem: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 14, borderRadius: 14 },
  drawerItemIcon: { fontSize: 20, marginRight: 14, width: 28, textAlign: 'center' },
  drawerItemLabel: { flex: 1, fontSize: 16, fontWeight: '500' },
  drawerArrow: { fontSize: 22 },
  drawerDivider: { height: 1, marginHorizontal: 20, marginVertical: 12 },
});
